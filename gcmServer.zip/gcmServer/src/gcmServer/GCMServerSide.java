package gcmServer;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
 
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;

public class GCMServerSide {
	public void sendMessage(ArrayList<String> aList) throws IOException {

		Sender sender = new Sender("AIzaSyAYqRc6xv-UkbUyNeJmks9lQjhx1rR86es");

		String title = "�¿���";
		String msg = "�� ������ �����ʹ� �� ������ ���� �ִ�??";
		
		 try {
			   title = java.net.URLEncoder.encode(title,"utf-8");
			   msg = java.net.URLEncoder.encode(msg,"utf-8");

			 } catch (UnsupportedEncodingException e1) {
			   // TODO Auto-generated catch block
			   e1.printStackTrace();
			  }


		Message message = new Message.Builder()
				  .collapseKey(
				    String.valueOf(Math.random() % 100 + 1))
				    .delayWhileIdle(false).timeToLive(1300)
				    .addData("no","1")
				    .addData("title", title)
				    .addData("message", msg)
				    .build();
		
		
		List<String> list = aList;
		
		MulticastResult multiResult = sender.send(message, list, 5);

		
		if (multiResult != null) {

			List<Result> resultList = multiResult.getResults();

			for (Result result : resultList) {

				System.out.println(result.getMessageId());
			}
		}
	}

	public static void main(String[] args) throws Exception {

		GCMServerSide s = new GCMServerSide();
        connmysql a = new connmysql();

        ArrayList<String> list = a.testMySql();
        s.sendMessage(list);

	}
}