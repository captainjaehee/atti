package com.example.hoon.demo.gcm;

import android.app.Application;

/**
 * Created by Hoon on 2016-04-07.
 */
public class Myapplication extends Application {

        // RegistrationIntentService를 실행 후 생성된 registration ID를 전역변수 처럼 활용하기 위하여 정의
        private String mGlobalString;

        public String getGlobalString()
        {
            return mGlobalString;
        }

        public void setGlobalString(String globalString)
        {
            this.mGlobalString = globalString;
        }
}
