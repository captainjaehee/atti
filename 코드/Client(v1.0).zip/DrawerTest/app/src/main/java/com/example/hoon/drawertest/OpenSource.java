package com.example.hoon.drawertest;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class OpenSource extends Activity {

    private TextView client, server;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.opensource);

        client = (TextView)findViewById(R.id.client);
        server = (TextView)findViewById(R.id.server);

        client.setText("\nAndroid- platform - packages - apps - Client(V1.0)\n https://github.com/captainjaehee/atti/blob/%EC%84%A4%EA%B3%84%EC%84%9C/%EC%BD%94%EB%93%9C/Client(v1.0).zip\n\n");
        server.setText("Android- platform - packages - apps - Server(V1.0)\n https://github.com/captainjaehee/atti/blob/%EC%84%A4%EA%B3%84%EC%84%9C/%EC%BD%94%EB%93%9C/Server(v1.0).zip");
    }
}



