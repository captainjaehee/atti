package com.example.hoon.drawertest;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Hoon on 2016-06-09.
 */
public class PageFragment extends Fragment {

    private String mPageNmae;
    private int pos;

    protected static ArrayList<MovieInfo> list = new ArrayList<MovieInfo>();

    public static PageFragment create(int position, ArrayList<MovieInfo> info) {
        list=info;
        PageFragment fragment = new PageFragment();
        Bundle args = new Bundle();
        args.putString("name", list.get(position).getName());
        args.putInt("num",position);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPageNmae = getArguments().getString("name");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        pos = getArguments().getInt("num");

        URL imgUrl = null;
        HttpURLConnection connection = null;
        InputStream is = null;
        Bitmap retBitmap = null;

        try {
            imgUrl = new URL(list.get(pos).getImage());
            connection = (HttpURLConnection) imgUrl.openConnection();
            connection.setDoInput(true);
            connection.connect();
            is = connection.getInputStream();
            retBitmap = BitmapFactory.decodeStream(is);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.movie_item, container, false);
        ((TextView) rootView.findViewById(R.id.name)).setText(mPageNmae);
        ((ImageView) rootView.findViewById(R.id.image)).setImageBitmap(retBitmap);
        Drawable alpha = ((ImageView) rootView.findViewById(R.id.image)).getDrawable();
        alpha.setAlpha(110);
        ((ImageView) rootView.findViewById(R.id.image)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(list.get(pos).getSrc()));
                startActivity(intent);
            }
        });
        ((TextView) rootView.findViewById(R.id.name)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(list.get(pos).getSrc()));
                startActivity(intent);
            }
        });

        return rootView;
    }
}