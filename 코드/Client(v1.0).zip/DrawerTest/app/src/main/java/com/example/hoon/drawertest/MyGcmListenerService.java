package com.example.hoon.drawertest;

/**
 * Created by Hoon on 2016-03-23.
 */

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.gcm.GcmListenerService;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * Created by saltfactory on 6/8/15.
 */
public class MyGcmListenerService extends GcmListenerService {

    private static final String TAG = "MyGcmListenerServ.3ice";

    /**
     *
     * @param from SenderID 값을 받아온다.
     * @param data Set형태로 GCM으로 받은 데이터 payload이다.
     */
    @Override
    public void onMessageReceived(String from, Bundle data) {
        // server에서 보낸 메시지를 받아서 저장
        String title = data.getString("title");
        String message = data.getString("message");

        Log.d(TAG, "From: " + from);
        Log.d(TAG, "Title: " + title);
        Log.d(TAG, "Message: " + message);

        // encode된 값을 decode해준다.
        try {
            title = URLDecoder.decode(title,"utf-8");
            message = URLDecoder.decode(message,"utf-8");
        } catch (UnsupportedEncodingException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        // GCM으로 받은 메세지를 디바이스에 알려주는 sendNotification()을 호출한다.
        sendNotification(title, message);
    }


    /**
     * 실제 디바에스에 GCM으로부터 받은 메세지를 알려주는 함수이다. 디바이스 Notification Center에 나타난다.
     * @param title
     * @param message
     */
    private void sendNotification(String title, String message) {
        Intent intent = new Intent(this, MainActivity.class);
        //동일한 ACTIVITY가 생성될 경우 이전 ACTIVITY를 제거
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent, PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        // 디바이스에 띄워 줄 푸시 알림 상세설정
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                // 푸시 알림의 아이콘 이미지
                .setSmallIcon(R.drawable.movie)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.movie))
                .setContentTitle(title)
                // 푸시 알림 메시지
                .setContentText(message)
                // 푸시 알림 클릭 시 해당 APP을 실행하며 자동으로 알림 제거
                .setAutoCancel(true)
                // 푸시 알림시 사운드
                .setSound(defaultSoundUri)
                // 푸시 알림 클릭 시 반응해줄 인텐트 지정
                .setContentIntent(pendingIntent);
                //  추가로 setTicker("") 는 알림 클릭 시 상태바에 잠시 띄워줄 텍스트 지정

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        // 설정된 값에 따라 푸시 알림
            notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }
}