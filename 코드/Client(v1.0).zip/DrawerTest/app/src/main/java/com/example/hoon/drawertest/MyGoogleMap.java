package com.example.hoon.drawertest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Created by Hoon on 2016-06-02.
 */
public class MyGoogleMap extends Activity {
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String TAG = "MyGoogleMap";

    private LocationManager locationManager;
    private String provider;
    private Criteria criteria;
    private MyLocationListener mylistener;

    private Geocoder mCoder;
    private List<Address> addr;

    protected List<MovieInfo> mArray = new ArrayList<MovieInfo>();

    protected List<MovieInfo> mArray0 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray1 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray2 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray3 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray4 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray5 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray6 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray7 = new ArrayList<MovieInfo>();
    protected List<MovieInfo> mArray8 = new ArrayList<MovieInfo>();

    protected MovieAdapter mAdapter;

    private ListView LocalList;
    private ListView CinemaList;

    ArrayList<String> Local = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    private Location loc1 = null;
    phpDown4 task4;
    private String[][] Movie_List3;
    private String[] List_str;
    private int ListNumber=9;
    private StringBuffer bf;


    //Google Map
    @SuppressLint("InlinedApi") @SuppressWarnings("deprecation")
    public static int getLocationMode(Context context) {
        int locationMode = Settings.Secure.LOCATION_MODE_OFF;
        String locationProviders;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
            try {
                locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);
            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
            }
        }else{
            locationProviders = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);

            if (TextUtils.isEmpty(locationProviders)){
                locationMode = Settings.Secure.LOCATION_MODE_OFF;
            }
            else if (locationProviders.contains(LocationManager.GPS_PROVIDER) && locationProviders.contains(LocationManager.NETWORK_PROVIDER)){
                locationMode = Settings.Secure.LOCATION_MODE_HIGH_ACCURACY;
            }
            else if (locationProviders.contains(LocationManager.GPS_PROVIDER)){
                locationMode = Settings.Secure.LOCATION_MODE_SENSORS_ONLY;
            }
            else if (locationProviders.contains(LocationManager.NETWORK_PROVIDER)){
                locationMode = Settings.Secure.LOCATION_MODE_BATTERY_SAVING;
            }
        }
        return locationMode;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cineserch);

        task4 = new phpDown4();
        String[] List_str = new String[10];
        Movie_List3 = new String[3][256];
        for(int i=0; i<10; i++)
            List_str[i]=null;
        for (int i = 0; i < 256; i++) {
            Movie_List3[0][i] = null;
            Movie_List3[1][i] = null;
            Movie_List3[2][i] = null;
        }

        task4.execute("http://192.168.25.7/myphp4.php");

        Intent intent = new Intent(this.getIntent());

        Local.add("가까운영화관");
        Local.add("서울");
        Local.add("경기/인천");
        Local.add("충청/대전");
        Local.add("경북/대구");
        Local.add("경남/부산/울산");
        Local.add("전라/광주");
        Local.add("강원");
        Local.add("제주");


        mCoder = new Geocoder(this);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);
        criteria.setBearingRequired(true);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        criteria.setCostAllowed(true);
        provider = locationManager.getBestProvider(criteria, true);

        int mode = getLocationMode(this);

        switch (mode) {
            case Settings.Secure.LOCATION_MODE_OFF:
                Toast.makeText(MyGoogleMap.this, "LOCATION_MODE_OFF", Toast.LENGTH_SHORT).show();
                break;

            case Settings.Secure.LOCATION_MODE_SENSORS_ONLY:
                Toast.makeText(MyGoogleMap.this, "LOCATION_MODE_SENSORS_ONLY = GPS_PROVIDER", Toast.LENGTH_SHORT).show();
                break;

            case Settings.Secure.LOCATION_MODE_BATTERY_SAVING:
                Toast.makeText(MyGoogleMap.this, "LOCATION_MODE_BATTERY_SAVING = NETWORK_PROVIDER", Toast.LENGTH_SHORT).show();
                break;

            case Settings.Secure.LOCATION_MODE_HIGH_ACCURACY:
                Toast.makeText(MyGoogleMap.this, "LOCATION_MODE_HIGH_ACCURACY = GPS_PROVIDER+NETWORK_PROVIDER", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }

        //providerì˜ last known location
        Location location = null;
        try {
            location = locationManager.getLastKnownLocation(provider);
        } catch (SecurityException e) {
            Log.e("PERMISSION_EXCEPTION", "PERMISSION_NOT_GRANTED");
        }

        mylistener = new MyLocationListener();

        if (location != null) {
            mylistener.onLocationChanged(location);
        } else {
            Intent intent1 = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(intent1);
        }

        LocalList=(ListView)findViewById(R.id.local_list);
        LocalList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,Local);
        LocalList.setAdapter(adapter);

        LocalList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ListNumber = position;
                switch (position) {
                    case 0:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 1:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 2:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 3:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 4:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 5:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 6:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 7:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;
                    case 8:
                        CinemaList.setAdapter(mAdapter);
                        CinemaList.setOnItemClickListener(onClickListItem);
                        break;

                }
            }
        });
        findAddress(loc1.getLatitude(),loc1.getLongitude());
    }

    public void Degree(){
        final CharSequence[] items = new CharSequence[mArray.size()];

        for (int i =0; i < mArray0.size(); i++) {
            String str = mArray0.get(i).address;
            try {
                //주소값을 통하여 로케일을 받아온다
                addr = mCoder.getFromLocationName(str, 10);
                Double Lat = addr.get(0).getLatitude();
                Double Lon = addr.get(0).getLongitude();
                //해당 로케일로 좌표를 구성한다
                LatLng newLatLng = new LatLng(Lat, Lon);
            } catch (Exception e) {
                continue;
            }
            double lat1 = Double.valueOf(loc1.getLatitude()).doubleValue();
            double lon1 = Double.valueOf(loc1.getLongitude()).doubleValue();
            double lat2 = Double.valueOf(addr.get(0).getLatitude()).doubleValue();
            double lon2 = Double.valueOf(addr.get(0).getLongitude()).doubleValue();

            double degree = calDistance(lat1, lon1, lat2, lon2);
            double deg = Double.parseDouble(String.format("%.2f", degree));
            mArray0.get(i).setDegree(deg);

        }
        Collections.sort(mArray0, new Comparator<MovieInfo>() {
            public int compare(MovieInfo obj1, MovieInfo obj2) {
                // TODO Auto-generated method stub
                return (obj1.degree < obj2.degree) ? -1 : (obj1.degree > obj2.degree) ? 1 : 0;
            }
        });
    }

    //현재위치의 위도,경도 좌표로 주소값 획득
    public String findAddress(double lat, double lng) {
        bf = new StringBuffer();
        Geocoder geocoder = new Geocoder(this, Locale.KOREA);
        List<Address> address;
        String currentLocationAddress;
        try {
            if (geocoder != null) {
                // 세번째 인수는 최대결과값인데 하나만 리턴받도록 설정했다
                address = geocoder.getFromLocation(lat, lng, 1);
                // 설정한 데이터로 주소가 리턴된 데이터가 있으면
                if (address != null && address.size() > 0) {
                    // 주소
                    currentLocationAddress = address.get(0).getAddressLine(0).toString();

                    // 전송할 주소 데이터 (위도/경도 포함 편집)
                    //bf.append(address.get(0).getAdminArea());//도,광역시
                    bf.append(address.get(0).getLocality());//시,구,군
                }
            }

        } catch (IOException e) {
            Toast.makeText(this, "주소취득 실패", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        bf=replaceStr(bf);
        return bf.toString();
    }

    public StringBuffer replaceStr(StringBuffer bf){
        String str;
        int i = bf.length();
        bf=bf.delete(i - 1, i);

        return bf;
    }

    public class MovieInfo {
        String address;//date;
        String cinema;//min;
        double degree;//max;

        public MovieInfo(String address, String cinema, double degree) {
            super();
            this.address = address;
            this.cinema = cinema;
            this.degree = degree;
        }
        public void setAddress(String address) { this.address=address; }
        public void setCinema(String cinema) { this.cinema=cinema; }
        public void setDegree(double degree) {
            this.degree=degree;
        }

        public String getAddress() { return address; }
        public String getCinema() { return cinema; }
        public double getDegree() {
            return degree;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        try {
            locationManager.removeUpdates(mylistener);
        } catch (SecurityException e) {
            Log.e("PERMISSION_EXCEPTION", "PERMISSION_NOT_GRANTED");
        }
    }

    private class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {
            loc1=location;
        }


        // 프로바이더의 상태값이 변경되었을경우에 호출된다.
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            switch (status) {
                case LocationProvider.AVAILABLE:
                    Toast.makeText(MyGoogleMap.this, provider +" state visible", Toast.LENGTH_SHORT).show();
                    break;
                case LocationProvider.OUT_OF_SERVICE:
                    Toast.makeText(MyGoogleMap.this, provider +" out of service", Toast.LENGTH_SHORT).show();
                    break;
                case LocationProvider.TEMPORARILY_UNAVAILABLE:
                    Toast.makeText(MyGoogleMap.this, provider +" service stop", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

        // 사용자에 의해 프로바이더가 활성화 되었을경우 호출된다.
        @Override
        public void onProviderEnabled(String provider) {
            Toast.makeText(MyGoogleMap.this, "Provider " + provider + " enabled!", Toast.LENGTH_SHORT).show();
        }
        // 사용자에 의해 프로바이더가 비활성화 되었을경우 호출된다.
        @Override
        public void onProviderDisabled(String provider) {
            Toast.makeText(MyGoogleMap.this, "Provider " + provider + " disabled!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(intent);
        }
    }

    public double calDistance(double lat1, double lon1, double lat2, double lon2){
        double theta, dist;
        theta = lon1 - lon2;
        dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1))
                * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);

        dist = dist * 60 * 1.1515;
        dist = dist * 1.609344;    // 단위 mile 에서 km 변환.
//        dist = dist * 1000.0;      // 단위  km 에서 m 로 변환

        return dist;
    }
    // 주어진 도(degree) 값을 라디언으로 변환
    private double deg2rad(double deg){
        return (double)(deg * Math.PI / (double)180d);
    }
    // 주어진 라디언(radian) 값을 도(degree) 값으로 변환
    private double rad2deg(double rad){
        return (double)(rad * (double)180d / Math.PI);
    }


    private AdapterView.OnItemClickListener onClickListItem = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> arg0, View arg1,final int arg2, long arg3) {
                        Intent intent;
                if(ListNumber==0) {
                    switch (arg2) {
                        case 0:
                            intent = new Intent(MyGoogleMap.this, InfoDetail.class);
                            intent.putExtra("title", mArray0.get(arg2).getCinema());
                            startActivity(intent);
                            break;
                        case 1:
                            intent = new Intent(MyGoogleMap.this, InfoDetail.class);
                            intent.putExtra("title", mArray0.get(arg2).getCinema());
                            startActivity(intent);
                            break;
                        case 2:
                            intent = new Intent(MyGoogleMap.this, InfoDetail.class);
                            intent.putExtra("title", mArray0.get(arg2).getCinema());
                            startActivity(intent);
                            break;
                        case 3:
                            intent = new Intent(MyGoogleMap.this, InfoDetail.class);
                            intent.putExtra("title", mArray0.get(arg2).getCinema());
                            startActivity(intent);
                            break;
                        case 4:
                            intent = new Intent(MyGoogleMap.this, InfoDetail.class);
                            intent.putExtra("title", mArray0.get(arg2).getCinema());
                            startActivity(intent);
                            break;
                    }
                }
        }
    };

    static class MovieViewHolder {
        TextView txtView;
    }
    public class MovieAdapter extends ArrayAdapter<MovieInfo> {
        private LayoutInflater mInflater = null;
        public MovieAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }
        @Override
        public int getCount() {
            if(ListNumber==1)
                return mArray1.size();
            else if(ListNumber==2)
                return mArray2.size();
            else if(ListNumber==3)
                return mArray3.size();
            else if(ListNumber==4)
                return mArray4.size();
            else if(ListNumber==5)
                return mArray5.size();
            else if(ListNumber==6)
                return mArray6.size();
            else if(ListNumber==7)
                return mArray7.size();
            else if(ListNumber==8)
                return mArray8.size();
            else if(ListNumber==0)
                return mArray0.size();
            else return mArray.size();
        }
        @Override
        public View getView(int position, View v, ViewGroup parent) {
            MovieViewHolder viewHolder;

            if (v == null) {
                v = mInflater.inflate(R.layout.cinema_info, parent, false);
                viewHolder = new MovieViewHolder();
                viewHolder.txtView = (TextView) v.findViewById(R.id.cinema);
                v.setTag(viewHolder);
            }
            else {
                viewHolder = (MovieViewHolder) v.getTag();
            }
            MovieInfo info,info2 = null;

            info = mArray.get(position);

           if(ListNumber==1)
                info2 = mArray1.get(position);
            else if((ListNumber==2))
                info2 = mArray2.get(position);
            else if((ListNumber==3))
                info2 = mArray3.get(position);
           else if((ListNumber==4))
               info2 = mArray4.get(position);
           else if((ListNumber==5))
               info2 = mArray5.get(position);
           else if((ListNumber==6))
               info2 = mArray6.get(position);
           else if((ListNumber==7))
               info2 = mArray7.get(position);
           else if((ListNumber==8))
               info2 = mArray8.get(position);
           else if((ListNumber==0))
               info2 = mArray0.get(position);

            if (info != null) {
                if(ListNumber == 9){
                    viewHolder.txtView.setText(info.getCinema() + " " + info.getDegree() + "km");
                }
                else if(ListNumber == 0)
                    viewHolder.txtView.setText(info2.getCinema() + " " + info2.getDegree() + "km");
                else
                    viewHolder.txtView.setText(info2.getCinema());
            }
            return v;
        }
    }



    public void insertData() {
        for (int i = 0; i < 64; i++) {
            if (Movie_List3[0][i] == null)
                break;
            mArray.add(new MovieInfo(Movie_List3[0][i], Movie_List3[1][i], //Double.valueOf(Movie_List3[2][i]).doubleValue()));
                    Double.parseDouble(Movie_List3[2][i])));
            if( mArray.get(i).getAddress().toString().contains("서울"))
                mArray1.add(mArray.get(i));
            else if(( mArray.get(i).getAddress().contains("경기도")|| mArray.get(i).getAddress().contains("인천")))
                mArray2.add(mArray.get(i));

            else if(( mArray.get(i).getAddress().contains("충청")|| mArray.get(i).getAddress().contains("대전")))
                mArray3.add(mArray.get(i));

            else if(mArray.get(i).getAddress().contains("경상북도")|| mArray.get(i).getAddress().contains("대구"))
                mArray4.add(mArray.get(i));

            else if( mArray.get(i).getAddress().contains("경상남도")|| mArray.get(i).getAddress().contains("부산")|| mArray.get(i).getAddress().contains("울산"))
                mArray5.add(mArray.get(i));

            else if( mArray.get(i).getAddress().contains("전라")|| mArray.get(i).getAddress().contains("광주"))
                mArray6.add(mArray.get(i));

            else if( mArray.get(i).getAddress().contains("강원"))
                mArray7.add(mArray.get(i));

            else if( mArray.get(i).getAddress().contains("제주"))
                mArray8.add(mArray.get(i));

            if( mArray.get(i).getAddress().contains(bf.toString()))
                mArray0.add(mArray.get(i));

        }
    }


    class phpDown4 extends AsyncTask<String, Integer, String> {
        ProgressDialog loading;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(MyGoogleMap.this, "Please Wait", null, true, true);
        }

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List3[0][i] = jObject.getString("address");
                    Movie_List3[1][i] = jObject.getString("cinema");
                    Movie_List3[2][i] = jObject.getString("degree");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            insertData();
            Degree();
            mAdapter = new MovieAdapter(MyGoogleMap.this, R.layout.cinema_info);
            CinemaList = (ListView) findViewById(R.id.cinema_list);
            CinemaList.setOnItemClickListener(onClickListItem);
            loading.dismiss();
        }
    }

}
