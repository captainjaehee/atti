package com.example.hoon.drawertest;

/**
 * Created by Hoon on 2016-06-15.
 */
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MovieSerch extends Activity {
    private phpDown task;
    private phpDown2 task2;
    private phpDown3 task3;
    private String[][] Movie_List;
    private String[][] Movie_List2;
    private String[][] Movie_List3;

    ArrayList<String> s_list = new ArrayList<String>();
    ArrayAdapter<String> sAdapter;

    Button serch;
    ListView sch_list;
    ImageView s_image;
    TextView s_movie;
    EditText et;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movieserch);
        et = (EditText)findViewById(R.id.input);
        et.getBackground().setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
        s_image = (ImageView)findViewById(R.id.s_image);
        task = new phpDown();
        task2 = new phpDown2();
        task3 = new phpDown3();

        Movie_List = new String[3][500];
        Movie_List2 = new String[3][500];
        Movie_List3 = new String[5][255];

        for (int i = 0; i < 500; i++) {
            Movie_List[0][i] = null;
            Movie_List[1][i] = null;
            Movie_List[2][i] = null;
            Movie_List2[0][i] = null;
            Movie_List2[1][i] = null;
            Movie_List2[2][i] = null;
        }
        task.execute("http://192.168.25.7/myphp.php");
        task2.execute("http://192.168.25.7/myphp2.php");
        task3.execute("http://192.168.25.7/myphp3.php");

        serch=(Button)findViewById(R.id.s_button);
        serch.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                doitnow();
            }
        });

    }

    class phpDown extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List[0][i] = jObject.getString("num");
                    Movie_List[1][i] = jObject.getString("name");
                    Movie_List[2][i] = jObject.getString("cinema");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class phpDown2 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List2[0][i] = jObject.getString("num");
                    Movie_List2[1][i] = jObject.getString("time");
                    Movie_List2[2][i] = jObject.getString("movienum");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class phpDown3 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List3[0][i] = jObject.getString("num");
                    Movie_List3[1][i] = jObject.getString("name");
                    Movie_List3[2][i] = jObject.getString("url");
                    Movie_List3[3][i] = jObject.getString("img");
                    Movie_List3[4][i] = jObject.getString("cur");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    public void img_Bitmap(String img){
        URL imgUrl = null;
        HttpURLConnection connection = null;
        InputStream is = null;
        Bitmap retBitmap = null;

        try {
            imgUrl = new URL(img);
            connection = (HttpURLConnection) imgUrl.openConnection();
            connection.setDoInput(true);
            connection.connect();
            is = connection.getInputStream();
            retBitmap = BitmapFactory.decodeStream(is);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        s_image.setImageBitmap(retBitmap);
    }

    public void onButton1(View v) {
        doitnow();
    }

    public void doitnow() {
        sch_list = (ListView) findViewById(R.id.s_list);
        s_movie = (TextView) findViewById(R.id.s_movie);
        s_movie.setText("");
        img_Bitmap(null);
        s_list.clear();
        sch_list.setAdapter(sAdapter);
        boolean ok = true;

        if (et.getText().toString().equals("")){
            Toast.makeText(this, "검색어를 입력하세요.",Toast.LENGTH_SHORT).show();
            return;
        }
        for(int i=0; i<500; i++) {
            if(Movie_List3[1][i]==null)
                break;
            if (Movie_List3[1][i].contains(et.getText().toString())) {
                img_Bitmap(Movie_List3[2][i]);
                break;
            }
        }

        String str=null;
        for(int i=0;i<500;i++)
        {
            if(Movie_List[1][i]==null)
                break;
            if(Movie_List[1][i].contains(et.getText().toString())) {
                str=Movie_List[1][i];
                s_movie.append(Movie_List[2][i] + "\n");

                for(int j=0;j<500;j++)
                {
                    if(Movie_List2[0][j]==null)
                        break;
                    if(Movie_List[0][i].equals(Movie_List2[2][j]))
                        s_movie.append(Movie_List2[1][j] + " ");
                }
                s_list.add(s_movie.getText().toString());
                s_movie.setText("");
            }
            else
                continue;
        }
        s_movie.setText(str);

        sAdapter = new ArrayAdapter<String>(MovieSerch.this,android.R.layout.simple_list_item_1,s_list);
        sch_list.setAdapter(sAdapter);

        if(s_movie.getText().toString()==null)
            Toast.makeText(this, "검색 결과가 없습니다.",Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this,et.getText().toString() + "로 검색한 결과",Toast.LENGTH_SHORT).show();
        et.setText("");

        sch_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(MovieSerch.this, position, Toast.LENGTH_SHORT).show();
                //Toast.makeText(MovieSerch.this, s_list.get(position), Toast.LENGTH_SHORT).show();
                if(s_list.get(position).contains("롯데시네마 구미점")) {
                    Intent intent;
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://movie.naver.com/movie/bi/ti/running.nhn?code=168"));
                    startActivity(intent);
                }
                else if(s_list.get(position).contains("롯데시네마 구미공단점")) {
                    Intent intent;
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://movie.naver.com/movie/bi/ti/running.nhn?code=167"));
                    startActivity(intent);
                }
                else if(s_list.get(position).contains("메가박스 구미강동점")) {
                    Intent intent;
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://movie.naver.com/movie/bi/ti/running.nhn?code=451"));
                    startActivity(intent);
                }
                else if(s_list.get(position).contains("메가박스 구미점")) {
                    Intent intent;
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://movie.naver.com/movie/bi/ti/running.nhn?code=478"));
                    startActivity(intent);
                }
                else{
                    Intent intent;
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.cgv.co.kr/theaters/?areacode=204&theaterCode=0053&date=20140707"));
                    startActivity(intent);
                }
            }
        });
    }
}