package com.example.hoon.drawertest;

/**
 * Created by samsung on 2016-04-07.
 */
public class MovieInfo {
    private String name;
    private String image;
    private String src;

    public MovieInfo(String name_, String image_, String src_) {
        super();
        this.name = name_;
        this.image = image_;
        this.src = src_;
    }
    public String getName() {
        return name;
    }
    public String getImage() {
        return image;
    }
    public String getSrc() {
        return src;
    }
}
