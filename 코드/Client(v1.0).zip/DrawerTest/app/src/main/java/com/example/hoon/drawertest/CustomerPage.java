package com.example.hoon.drawertest;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CustomerPage extends Activity {

    private ListView developer;

    ArrayList<String> info = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_page);

        developer = (ListView)findViewById(R.id.custom_list);

        info.add("오픈소스 라이센스");
        info.add("문의하기");
        info.add(" ");
        info.add("조원소개");
        info.add("팀명 : atti");
        info.add("대표 : 박재희");
        info.add("팀원 : 이경훈 장태영 장민정");
        info.add("주소 : 경북 구미시 거의동 금오공과대학교");
        info.add("홈페이지 : https://github.com/captainjaehee/atti");

        developer.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        adapter = new ArrayAdapter<String>(CustomerPage.this,android.R.layout.simple_list_item_1,info);
        developer.setAdapter(adapter);

        developer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0){
                    Intent intent =new Intent(CustomerPage.this,OpenSource.class);
                            startActivity(intent);
                }
                else if(position == 1){
                    AlertDialog.Builder builder = new AlertDialog.Builder(CustomerPage.this);
                    builder.setTitle("문의하기");
                    builder.setMessage("전화 : 010.2922.5563\ne-mail : wjhv115@naver.com\n주소 : 경북 구미시 거의동 603-6 애플빌 302호");
                    builder.setNeutralButton("닫기", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.show();
                }
            }
        });
    }
}



