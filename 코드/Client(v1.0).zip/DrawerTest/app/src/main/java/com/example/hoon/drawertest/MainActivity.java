package com.example.hoon.drawertest;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String TAG = "MainActivity";

    private ViewPager mViewPager;
    private PagerAdapter mPagerAdapter;

    public RecyclerView mRecyclerView;
    public RecyclerView.Adapter rAdapter;
    public LinearLayoutManager layoutManager = new LinearLayoutManager(this);



    private ArrayList<MovieInfo> mArray = new ArrayList<MovieInfo>();
    private ArrayList<MovieInfo> mArray2 = new ArrayList<MovieInfo>();

    boolean is_cur = true;
    public phpDown3 task3;
    public String[][] Movie_List3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        task3 = new phpDown3();

        Movie_List3 = new String[5][255];
        for (int i = 0; i < 255; i++) {
            Movie_List3[0][i] = null;
            Movie_List3[1][i] = null;
            Movie_List3[2][i] = null;
            Movie_List3[3][i] = null;
            Movie_List3[4][i] = null;
        }
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        StrictMode.enableDefaults();

        mViewPager = (ViewPager) findViewById(R.id.pager);
        mPagerAdapter = new PagerAdapter(getSupportFragmentManager());

        task3.execute("http://192.168.25.7/myphp3.php");

        getInstanceIdToken();

        mRecyclerView = (RecyclerView) findViewById(R.id.list);
        mRecyclerView.setHasFixedSize(true);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(layoutManager);

    }

    public void insertData() {
        for (int i = 0; i < 255; i++) {
            if (Movie_List3[0][i] == null)
                break;
            if (Movie_List3[4][i].equals("cur"))
                mArray.add(new MovieInfo(Movie_List3[1][i], Movie_List3[2][i], Movie_List3[3][i]));
            else
                mArray2.add(new MovieInfo(Movie_List3[1][i], Movie_List3[2][i], Movie_List3[3][i]));
        }
    }

    public void btn_cur(View v) {
        Button a = (Button)findViewById(R.id.cur_btn);
        Button b = (Button)findViewById(R.id.cur_exp);
        is_cur = true;
        mViewPager.setAdapter(mPagerAdapter);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            a.setBackground(this.getResources().getDrawable(R.drawable.mybutton));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            b.setBackground(this.getResources().getDrawable(R.drawable.mybutton2));
        }
        a.setTextColor(Color.parseColor("#ffffff"));
        b.setTextColor(Color.parseColor("#000000"));
    }

    public void btn_exp(View v) {
        Button a = (Button)findViewById(R.id.cur_btn);
        Button b = (Button)findViewById(R.id.cur_exp);
        is_cur = false;
        mViewPager.setAdapter(mPagerAdapter);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            b.setBackground(this.getResources().getDrawable(R.drawable.mybutton));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            a.setBackground(this.getResources().getDrawable(R.drawable.mybutton2));
        }
        b.setTextColor(Color.parseColor("#ffffff"));
        a.setTextColor(Color.parseColor("#000000"));
    }


    public void onButton_customer() {
        Intent intent = new Intent(MainActivity.this, CustomerPage.class);
        startActivity(intent);
    }

    public void onButton_alarm() {
        AlertDialog.Builder alert_confirm = new AlertDialog.Builder(MainActivity.this);

        alert_confirm.setMessage("푸시알림에 동의하시겠습니까?").setCancelable(false).setNegativeButton("동의",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Myapplication myApp = (Myapplication) getApplication();
                        String token = myApp.getGlobalString();
                        insertToDatabase(token);
                        Calendar calendar = new GregorianCalendar(Locale.KOREA);
                        Toast.makeText(MainActivity.this, calendar.get(Calendar.YEAR) + "." +
                                calendar.get(Calendar.MONTH) + 1 + "." + calendar.get(Calendar.DAY_OF_MONTH)
                                + " " + calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + ":"
                                + calendar.get(Calendar.SECOND) + " 푸시알림 수신 동의",Toast.LENGTH_SHORT).show();
                    }
                }).setPositiveButton("동의하지않음",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Calendar calendar = new GregorianCalendar(Locale.KOREA);
                        Toast.makeText(MainActivity.this, "푸시알림 수신 거부",Toast.LENGTH_SHORT).show();
                        return;
                    }
                });
        AlertDialog alert = alert_confirm.create();
        alert.show();
    }

    public void onButton_mega(View v) {
        final CharSequence[] items = {"메가박스 구미", "메가박스 구미강동"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int index) {
                        Intent intent = new Intent(MainActivity.this, InfoDetail.class);
                        switch (index) {
                            case 0:
                                intent.putExtra("title", items[index].toString());
                                break;
                            case 1:
                                intent.putExtra("title", items[index].toString());
                                break;
                        }
                        startActivity(intent);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void onButton_lotte(View v) {
        final CharSequence[] items = {"롯데시네마 구미", "롯데시네마 구미공단"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int index) {
                        Intent intent = new Intent(MainActivity.this, InfoDetail.class);
                        switch (index) {
                            case 0:
                                intent.putExtra("title", items[index].toString());
                                break;
                            case 1:
                                intent.putExtra("title", items[index].toString());
                                break;
                        }
                        startActivity(intent);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void onButton_CGV(View v) {
        final CharSequence[] items = {"CGV 구미"};

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int index) {
                        Intent intent = new Intent(MainActivity.this, InfoDetail.class);
                        intent.putExtra("title", items[index].toString());
                        startActivity(intent);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_rss) {
            onButton_customer();
        } else if (id == R.id.nav_alarm) {
            onButton_alarm();
        } else if (id == R.id.nav_cinema) {
            Intent intent = new Intent(MainActivity.this, MyGoogleMap.class);
            startActivity(intent);
        } else if (id == R.id.nav_movie) {
            Intent intent = new Intent(MainActivity.this, MovieSerch.class);
            startActivity(intent);
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    /**
     * Instance ID를 이용하여 디바이스 토큰을 가져오는 RegistrationIntentService를 실행한다.
     */
    public void getInstanceIdToken() {
        if (checkPlayServices()) {
            // Start IntentService to register this application with GCM.
            Intent intent = new Intent(this, RegistrationIntentService.class);
            startService(intent);
        }
    }

    /**
     * Google Play Service를 사용할 수 있는 환경이지를 체크한다.
     */
    private boolean checkPlayServices() {
        int resultCode = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GoogleApiAvailability.getInstance().isUserResolvableError(resultCode)) {
                GoogleApiAvailability.getInstance().getErrorDialog(this, resultCode,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.i(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }

    /**
     * token으로 전달된 deviceID를 DB로 전송한다.
     */
    private void insertToDatabase(String u_id) {
        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(MainActivity.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
            }

            @Override
            protected String doInBackground(String... params) {
                try {
                    String u_id = (String) params[0];
                    // ip주소/php 이름 , DB에 registration ID값을 저장하는 php파일을 불러온다
                    String link = "http://192.168.25.7/ps3reg.php";
                    // u_id = registration ID 값으로 UTF-8 형식으로 인코딩하여 전달
                    String data = URLEncoder.encode("u_id", "UTF-8") + "=" + URLEncoder.encode(u_id, "UTF-8");

                    // url에 php파일 주소값을 넣어 실행
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    // 문자 스트림에서 바이트 스트림으로의 변환을 제공하는 입출력 스트림
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    // 문자 입력 스트림으로부터 문자를 읽어 들일때 버퍼링을 함으로써 문자, 문자 배열, 문자열 라인 등을 보다 효율적으로 처리
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String("Exception: " + e.getMessage());
                }
            }
        }
        InsertData task = new InsertData();

        Log.v("registration ID 확인 :", u_id + "");
        task.execute(u_id);
    }

    class phpDown3 extends AsyncTask<String, Integer, String> {
        ProgressDialog loading;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(MainActivity.this, "Please Wait", null, true, true);
        }

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }


        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List3[0][i] = jObject.getString("num");
                    Movie_List3[1][i] = jObject.getString("name");
                    Movie_List3[2][i] = jObject.getString("url");
                    Movie_List3[3][i] = jObject.getString("img");
                    Movie_List3[4][i] = jObject.getString("cur");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            insertData();

            is_cur = true;
            rAdapter = new MyAdapter(mArray);
            mRecyclerView.setAdapter(rAdapter);

            mViewPager.setAdapter(mPagerAdapter);

            mViewPager.setPageTransformer(false, new ViewPager.PageTransformer() {

                //현재 Page의 위치가 조금이라도 바뀔때마다 호출되는 메소드
                //첫번째 파라미터 : 현재 존재하는 View 객체들 중에서 위치가 변경되고 있는 View들
                //두번째 파라미터 : 각 View 들의 상대적 위치( 0.0 ~ 1.0 : 화면 하나의 백분율)
                //           1.현재 보여지는 Page의 위치가 0.0
                //           Page가 왼쪽으로 이동하면 값이 -됨. (완전 왼쪽으로 빠지면 -1.0)
                //           Page가 오른쪽으로 이동하면 값이 +됨. (완전 오른쪽으로 빠지면 1.0)
                //주의할 것은 현재 Page가 이동하면 동시에 옆에 있는 Page(View)도 이동함.
                //첫번째와 마지막 Page 일때는 총 2개의 View가 메모리에 만들어져 잇음.
                //나머지 Page가 보여질 때는 앞뒤로 2개의 View가 메모리에 만들어져 총 3개의 View가 instance 되어 있음.
                //ViewPager 한번에 1장의 Page를 보여준다면 최대 View는 3개까지만 만들어지며
                //나머지는 메모리에서 삭제됨.-리소스관리 차원.
                @Override
                public void transformPage(View page, float position) {
                    // TODO Auto-generated method stub

                    //position 값이 왼쪽, 오른쪽 이동방향에 따라 음수와 양수가 나오므로 절대값 Math.abs()으로 계산
                    //position의 변동폭이 (-2.0 ~ +2.0) 사이이기에 부호 상관없이 (0.0~1.0)으로 변경폭 조절
                    //주석으로 수학적 연산을 설명하기에는 한계가 있으니 코드를 보고 잘 생각해 보시기 바랍니다.
                    float normalizedposition = Math.abs( 1 - Math.abs(position) );

                    page.setAlpha(normalizedposition);  //View의 투명도 조절
                    page.setScaleX(normalizedposition/2 + 0.5f); //View의 x축 크기조절
                    page.setScaleY(normalizedposition/2 + 0.5f); //View의 y축 크기조절
                    page.setRotationY(position * 80);   //View의 Y축(세로축) 회전 각도
                }
            });
            loading.dismiss();
        }
    }

//View Pager 사용하기 위한 Adapter정의
    private class PagerAdapter extends FragmentStatePagerAdapter {
        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }
        @Override
        public Fragment getItem(int position) {
            if(is_cur) {
                return PageFragment.create(position,mArray);
            }
            else {
                return PageFragment.create(position,mArray2);
            }
        }
        @Override
        public int getCount() {
            if(is_cur)
                return mArray.size();
            else
                return mArray2.size();
        }
    }
//RecyclerView Adapter정의
    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View view) {
                super(view);
            }
        }
        public MyAdapter(ArrayList<MovieInfo> myDataset) {}
        // Create new views (invoked by the layout manager)
        @Override
        public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.movie_item, parent, false);
            ViewHolder vh = new ViewHolder(view);
            return vh;
        }
        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {}
        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            if(is_cur)
            return mArray.size();
            else
            return mArray2.size();
        }
    }

}