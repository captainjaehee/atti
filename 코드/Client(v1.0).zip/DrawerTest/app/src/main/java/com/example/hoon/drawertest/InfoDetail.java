package com.example.hoon.drawertest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class InfoDetail extends Activity {
    LinearLayout a;
    private phpDown task;
    private phpDown2 task2;
    private phpDown3 task3;
    private String[][] Movie_List;
    private String[][] Movie_List2;
    private String[][] Movie_List3;
    private TextView title, main;
    private ListView detail_list;
    ArrayAdapter<String> sAdapter;
    ArrayList<String> dt_list = new ArrayList<String>();
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.detail_info);
        a = (LinearLayout)findViewById(R.id.layout);
        task = new phpDown();
        task2 = new phpDown2();
        task3 = new phpDown3();

        Movie_List = new String[3][500];
        Movie_List2 = new String[3][500];
        Movie_List3 = new String[5][500];

        for (int i = 0; i < 500; i++) {
            Movie_List[0][i] = null;
            Movie_List[1][i] = null;
            Movie_List[2][i] = null;
            Movie_List2[0][i] = null;
            Movie_List2[1][i] = null;
            Movie_List2[2][i] = null;
            Movie_List3[0][i] = null;
            Movie_List3[1][i] = null;
            Movie_List3[2][i] = null;
            Movie_List3[3][i] = null;
            Movie_List3[4][i] = null;
        }
        task.execute("http://192.168.25.7/myphp.php");
        task2.execute("http://192.168.25.7/myphp2.php");
        task3.execute("http://192.168.25.7/myphp3.php");

        detail_list = (ListView)findViewById(R.id.detail_list);

        detail_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String str = sAdapter.getItem(position).toString();
                StringBuffer strBf = new StringBuffer(str);
                int i = strBf.length();
                strBf = strBf.delete(i - (i - 2), i);
                str = strBf.toString();
                Intent intent;
                for (int j = 0; j < Movie_List3.length; j++) {
                    if (Movie_List3[1][j].contains(str)) {
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Movie_List3[3][j]));
                        startActivity(intent);
                    }
                }
            }
        });
    }

    class phpDown extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List[0][i] = jObject.getString("num");
                    Movie_List[1][i] = jObject.getString("name");
                    Movie_List[2][i] = jObject.getString("cinema");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class phpDown2 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List2[0][i] = jObject.getString("num");
                    Movie_List2[1][i] = jObject.getString("time");
                    Movie_List2[2][i] = jObject.getString("movienum");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class phpDown3 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            try {
                JSONArray jarray = new JSONArray(str);
                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                    Movie_List3[0][i] = jObject.getString("num");
                    Movie_List3[1][i] = jObject.getString("name");
                    Movie_List3[2][i] = jObject.getString("url");
                    Movie_List3[3][i] = jObject.getString("img");
                    Movie_List3[4][i] = jObject.getString("cur");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            doitnow();

        }
    }

    public void doitnow() {
        title = (TextView) findViewById(R.id.title);
        title.setText(getIntent().getStringExtra("title"));
        main = (TextView) findViewById(R.id.cont);
        detail_list = (ListView) findViewById(R.id.detail_list);
        detail_list.setAlpha((float) 0.5);
        main.setText("");
        if (getIntent().getStringExtra("title").equals("롯데시네마 구미")) {
            dt_list.clear();
            for (int i = 0; i < 500; i++) {
                if(Movie_List[2][i] == null)
                    break;
                if (Movie_List[2][i].equals("롯데시네마 구미점")) {
                    main.append(Movie_List[1][i] + "\n");
                    for (int j = 0; j < 500; j++) {
                        if (Movie_List2[0][j] == null) {
                            main.append("\n");
                            break;
                        }
                        if (Movie_List2[2][j].equals(Movie_List[0][i]))
                            main.append(Movie_List2[1][j] + " ");
                    }
                    dt_list.add(main.getText().toString());
                    main.setText("");
                } else
                    continue;
            }
            sAdapter = new ArrayAdapter<String>(InfoDetail.this,android.R.layout.simple_list_item_1,dt_list);
            detail_list.setAdapter(sAdapter);
        }
        else if (getIntent().getStringExtra("title").equals("롯데시네마 구미공단")){
            dt_list.clear();
            for (int i = 0; i < 500; i++) {
                if(Movie_List[2][i] == null)
                    break;
                if (Movie_List[2][i].equals("롯데시네마 구미공단점")) {
                    main.append(Movie_List[1][i] + "\n");
                    for (int j = 0; j < 500; j++) {
                        if (Movie_List2[2][j] == null) {
                            main.append("\n");
                            break;
                        }
                        if (Movie_List2[2][j].equals(Movie_List[0][i]))
                            main.append(Movie_List2[1][j] + " ");
                    }
                    dt_list.add(main.getText().toString());
                    main.setText("");
                } else
                    continue;
            }
            sAdapter = new ArrayAdapter<String>(InfoDetail.this,android.R.layout.simple_list_item_1,dt_list);
            detail_list.setAdapter(sAdapter);
        }
        else if (getIntent().getStringExtra("title").equals("메가박스 구미")){

            dt_list.clear();
            for (int i = 0; i < 500; i++) {
                if(Movie_List[2][i] == null)
                    break;
                if (Movie_List[2][i].equals("메가박스 구미점")) {
                    main.append(Movie_List[1][i] + "\n");
                    for (int j = 0; j < 500; j++) {
                        if (Movie_List2[2][j] == null) {
                            main.append("\n");
                            break;
                        }
                        if (Movie_List2[2][j].equals(Movie_List[0][i]))
                            main.append(Movie_List2[1][j] + " ");
                    }
                    dt_list.add(main.getText().toString());
                    main.setText("");
                } else
                    continue;
            }
            sAdapter = new ArrayAdapter<String>(InfoDetail.this,android.R.layout.simple_list_item_1,dt_list);
            detail_list.setAdapter(sAdapter);
        }
        else if (getIntent().getStringExtra("title").equals("메가박스 구미강동")){

            dt_list.clear();
            for (int i = 0; i < 500; i++) {
                if(Movie_List[2][i] == null)
                    break;
                if (Movie_List[2][i].equals("메가박스 구미강동점")) {
                    main.append(Movie_List[1][i] + "\n");
                    for (int j = 0; j < 500; j++) {
                        if (Movie_List2[2][j] == null) {
                            main.append("\n");
                            break;
                        }
                        if (Movie_List2[2][j].equals(Movie_List[0][i]))
                            main.append(Movie_List2[1][j] + " ");
                    }
                    dt_list.add(main.getText().toString());
                    main.setText("");
                } else
                    continue;
            }
            sAdapter = new ArrayAdapter<String>(InfoDetail.this,android.R.layout.simple_list_item_1,dt_list);
            detail_list.setAdapter(sAdapter);
        }
        else if (getIntent().getStringExtra("title").equals("CGV 구미")){
//            a.setBackgroundDrawable(getResources().getDrawable(R.drawable.cgv_logo));
            dt_list.clear();
            for (int i = 0; i < 500; i++) {
                if(Movie_List[2][i] == null)
                    break;
                if (Movie_List[2][i].equals("CGV 구미점")) {
                    main.append(Movie_List[1][i] + "\n");
                    for (int j = 0; j < 500; j++) {
                        if (Movie_List2[2][j] == null) {
                            main.append("\n");
                            break;
                        }
                        if (Movie_List2[2][j].equals(Movie_List[0][i]))
                            main.append(Movie_List2[1][j] + " ");
                    }
                    dt_list.add(main.getText().toString());
                    main.setText("");
                } else
                    continue;
            }
            sAdapter = new ArrayAdapter<String>(InfoDetail.this,android.R.layout.simple_list_item_1,dt_list);
            detail_list.setAdapter(sAdapter);
        }
    }
}
