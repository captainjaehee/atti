package kr.ac.kumoh.ce.s20110547.movie2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by samsung on 2016-04-07.
 */
public class InfoDetail extends Activity {
    TextView title, contents;
    Intent intent;
    URL url = null;
    String str;
    boolean cgv = false;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_info);

        intent = getIntent();
        title = (TextView)findViewById(R.id.title);
        title.setText(getIntent().getStringExtra("title") + "\n");

        if(getIntent().getStringExtra("title").equals("롯데시네마 구미점"))
            str= "http://movie.naver.com/movie/bi/ti/running.nhn?code=168";
        else if(getIntent().getStringExtra("title").equals("롯데시네마 구미공단점"))
            str= "http://movie.naver.com/movie/bi/ti/running.nhn?code=167";
        else if(getIntent().getStringExtra("title").equals("메가박스 구미점"))
            str= "http://movie.naver.com/movie/bi/ti/running.nhn?code=478";
        else if(getIntent().getStringExtra("title").equals("메가박스 구미강동점"))
            str= "http://movie.naver.com/movie/bi/ti/running.nhn?code=451";
        else if(getIntent().getStringExtra("title").equals("CGV 구미점")) {
//            str = "http://www.cgv.co.kr/common/showtimes/iframeTheater.aspx?areacode=204&theatercode=0053&date=20160512&screencodes=&screenratingcode=&regioncode=";
//            cgv = true;
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.cgv.co.kr/reserve/show-times/?areacode=204&theaterCode=0053&date=20160512"));
            startActivity(intent);
        }
        try {
            if(cgv)
                rss();
            else
                rss2();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void rss2() throws IOException {
        contents = (TextView)findViewById(R.id.cont);
        contents.setText("");
//        text = (TextView)findViewById(R.id.main_text);
//        text.setText("");
        try {
            //학사안내
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=130&board_no=&category_cd=&flag=");
            //http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=130&board_no=&group_no=-1&up_geul_no=-1&to_conf_no=&delete_yn=0&board_type=hm&C_PAGE=1&search_key=jemok&keyword=%ED%86%A0%EC%9D%B5&totalCnt=2559&paging=10
            //아르바이트
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=122&board_no=&category_cd=&flag=");
            //자유게시판
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=110&board_no=&category_cd=&flag=");
            //키워드검색
            //String keyword = getIntent().getStringExtra("value");
            //검색어 입력
//            String Estr = "";
//            try {
//                Estr = URLEncoder.encode(keyword , "UTF-8");
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//            }

            //한글 인코딩
            url = new URL(str);
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=130&board_no=&group_no=-1&up_geul_no=-1&to_conf_no=&delete_yn=0&board_type=hm&C_PAGE=1&search_key=jemok&keyword="+ Estr +"&totalCnt=2559&paging=10");
            //검색할 URL
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
//        movielist = new LinkedList<>();
        //LinkedList name = new LinkedList();
        String readLine = null;
        //라인 읽어오기
        boolean cur=true;
        try {
            InputStreamReader isr = new InputStreamReader(url.openStream(), "EUC-KR");
            BufferedReader br = new BufferedReader(isr);

            while ((readLine = br.readLine()) != null) {
                //오늘 날짜 뽑아오는거 하기
                if(readLine.contains("<th><a href=\"/movie/bi/mi/basic.nhn?code=")) {
                    //상영작 포함된 줄 찾기
                    String []split = readLine.split(";\">");
                    String []split2 = split[1].split("</a> <img");
                    //스트링 구분
                    //name.add(split2[0]);
//                   movielist.add(new Movie_Data(split2[0], null, null));
                    contents.append(split2[0]+"\n");
                }
                else if(readLine.contains("onClick=\"clickcr(this,'scd.time',")) {
                    //글 제목 포함된 줄 찾기
                    String []split = readLine.split(";\">");
                    String []split1 = split[1].split("</a>");
                    //스트링 구분
                    //name.add(split[1]);
//                    movielist.add(new Movie_Data(split[1], split5[0], "http://movie.naver.com" + split3[0]));
                    contents.append(split1[0]+"\n");
                }
            }
//            for (int i=0; i<mArray.size(); i++) {
//                Toast.makeText(this, mArray.get(i).getImage(),Toast.LENGTH_SHORT).show();
//////                adapter.add(movielist.get(i).getName());
//////                //text.append(movielist.get(i).getName() + "\n" + movielist.get(i).getSrc() + "\n" + movielist.get(i).getImage() + "\n");
//////                //출력
//           }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void rss() throws IOException {
        contents = (TextView)findViewById(R.id.cont);
        contents.setText("");
        try {
            url = new URL(str);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        String readLine = null;
        try {
            InputStreamReader isr = new InputStreamReader(url.openStream(), "EUC-KR");
            BufferedReader br = new BufferedReader(isr);
            while ((readLine = br.readLine()) != null) {
//                if(readLine.contains("</strong></a>\n")) {
//                    String []split = readLine.split("</strong></a>\n");
//                    contents.append(split[0]+"\n");
//                }
//                else if(readLine.contains("data-playstarttime=\"")) {
//                    String []split = readLine.split("data-playstarttime=\"");
//                    String []split1 = split[1].split("\" data-playendtime=\"");
//                    contents.append(split1[0]+"\n");
//                }
                contents.append(readLine+"\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
