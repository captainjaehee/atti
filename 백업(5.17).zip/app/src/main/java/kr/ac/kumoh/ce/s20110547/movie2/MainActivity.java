package kr.ac.kumoh.ce.s20110547.movie2;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    URL url = null;
//    ListView list;
//    ArrayAdapter<String> adapter;
//    LinkedList<Movie_Data> movielist;
//    protected ArrayList<MovieInfo> mArray = new ArrayList<MovieInfo>();
    protected ArrayList<MovieInfo> mArray = new ArrayList<MovieInfo>();
    protected ArrayList<MovieInfo> mArray2 = new ArrayList<MovieInfo>();
    protected ListView mList, mList2;
    protected MovieAdapter mAdapter, mAdapter2;
    boolean is_cur = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        StrictMode.enableDefaults();

//        adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.simple_list_item_my);
//
//        // Xml에서 추가한 ListView 연결
//        list = (ListView) findViewById(R.id.main_list);
//
//        // ListView에 어댑터 연결
//        list.setAdapter(adapter);
        try {
            rss();
            mAdapter = null;
            mList = null;
            is_cur = true;

            mAdapter = new MovieAdapter(this, R.layout.movie_item);
            mList = (ListView)findViewById(R.id.main_list);
            mList.setAdapter(mAdapter);
            // Handle the camera action
            mList.setOnItemClickListener(onClickListItem);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private AdapterView.OnItemClickListener onClickListItem = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> arg0, View arg1,final int arg2, long arg3) {
//            Intent intent = new Intent(MainActivity.this, FindActivity.class);
//            intent.putExtra("value", (String)arg0.getAdapter().getItem(arg2));
//            startActivity(intent);
            ///////////////////////////////
            final CharSequence[] items = {"정보보기", "영화관선택", "알람설정"};

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("")        // 제목 설정
                    .setItems(items, new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialog, int index){
                            switch(index)
                            {
                                case 0:
                                    Intent intent;
                                    if(is_cur)
                                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mArray.get(arg2).getSrc()));
                                    else
                                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mArray2.get(arg2).getSrc()));
                                    startActivity(intent);
                                    break;
                                case 1:
                                    break;
                                case 2:
                                    break;
                            }
                        }
                    });
            AlertDialog dialog = builder.create();
            dialog.show();
            ///////////////////////////////
        }
    };

    static class MovieViewHolder {
        TextView vh_name;
        ImageView vh_image;
    }

    public class MovieAdapter extends ArrayAdapter<MovieInfo> {

        private LayoutInflater mInflater = null;

        public MovieAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            if(is_cur)
                return mArray.size();
            else
                return mArray2.size();
        }
        @Override
        public View getView(int position, View v, ViewGroup parent) {
            MovieViewHolder viewHolder;
            if (v == null) {
                v = mInflater.inflate(R.layout.movie_item, parent, false);
                viewHolder = new MovieViewHolder();
                viewHolder.vh_name = (TextView) v.findViewById(R.id.name);
                viewHolder.vh_image = (ImageView) v.findViewById(R.id.image);
                v.setTag(viewHolder);
            }
            else {
                viewHolder = (MovieViewHolder) v.getTag();
            }

            MovieInfo info;
            if(is_cur)
                info =  mArray.get(position);
            else
                info = mArray2.get(position);

            if (info != null) {
                        viewHolder.vh_name.setText(info.getName());

                        URL imgUrl = null;
                        HttpURLConnection connection = null;
                        InputStream is = null;

                        Bitmap retBitmap = null;

                        try {
                            imgUrl = new URL(info.getImage());
                            connection = (HttpURLConnection) imgUrl.openConnection();
                            connection.setDoInput(true); //url로 input받는 flag 허용
                            connection.connect(); //연결
                            is = connection.getInputStream(); // get inputstream
                            retBitmap = BitmapFactory.decodeStream(is);
                        } catch (Exception e) {
                            e.printStackTrace();
                            return null;
                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                            viewHolder.vh_image.setImageBitmap(retBitmap);
                        }
            }
            return v;
        }
    }

    public void btn_cur(View v)
    {
        mAdapter = null;
        mList = null;
        is_cur = true;

        mAdapter = new MovieAdapter(this, R.layout.movie_item);
        mList = (ListView)findViewById(R.id.main_list);
        mList.setAdapter(mAdapter);
        // Handle the camera action
        mList.setOnItemClickListener(onClickListItem);
    }
    public void btn_exp(View v)
    {
        mAdapter2 = null;
        mList2 = null;
        is_cur = false;

        mAdapter2 = new MovieAdapter(this, R.layout.movie_item);
        mList2 = (ListView)findViewById(R.id.main_list);
        mList2.setAdapter(mAdapter2);
        // Handle the camera action
        mList2.setOnItemClickListener(onClickListItem);
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void onButton_mega(View v)
    {
        final CharSequence[] items = {"메가박스 구미점", "메가박스 구미강동점"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int index) {
                        Intent intent = new Intent(MainActivity.this, InfoDetail.class);
                        switch (index) {
                            case 0:
                                intent.putExtra("title", items[index].toString());
                                break;
                            case 1:
                                intent.putExtra("title", items[index].toString());
                                break;
                        }
                        startActivity(intent);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void onButton_lotte(View v)
    {
        final CharSequence[] items = {"롯데시네마 구미점", "롯데시네마 구미공단점"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int index) {
                        Intent intent = new Intent(MainActivity.this, InfoDetail.class);
                        switch (index) {
                            case 0:
                                intent.putExtra("title", items[index].toString());
                                break;
                            case 1:
                                intent.putExtra("title", items[index].toString());
                                break;
                        }
                        startActivity(intent);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void onButton_CGV(View v)
    {
        final CharSequence[] items = {"CGV 구미점"};

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int index) {
                        Intent intent = new Intent(MainActivity.this, InfoDetail.class);
                        intent.putExtra("title", items[index].toString());
                        startActivity(intent);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_rss) {

        } else if (id == R.id.nav_open) {

        } else if (id == R.id.nav_find) {

        } else if (id == R.id.nav_lotte) {
            onButton_lotte(null);
        } else if (id == R.id.nav_mega) {
            onButton_mega(null);
        } else if (id == R.id.nav_cgv) {
            onButton_CGV(null);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void rss() throws IOException {
//        text = (TextView)findViewById(R.id.main_text);
//        text.setText("");
        try {
            //학사안내
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=130&board_no=&category_cd=&flag=");
            //http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=130&board_no=&group_no=-1&up_geul_no=-1&to_conf_no=&delete_yn=0&board_type=hm&C_PAGE=1&search_key=jemok&keyword=%ED%86%A0%EC%9D%B5&totalCnt=2559&paging=10
            //아르바이트
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=122&board_no=&category_cd=&flag=");
            //자유게시판
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=110&board_no=&category_cd=&flag=");
            //키워드검색
            //String keyword = getIntent().getStringExtra("value");
            //검색어 입력
//            String Estr = "";
//            try {
//                Estr = URLEncoder.encode(keyword , "UTF-8");
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//            }

            //한글 인코딩
            url = new URL("http://movie.naver.com/movie/running/current.nhn");
            //url = new URL("http://kumoh.ac.kr/jsp/module/board/list01.do?conf_no=130&board_no=&group_no=-1&up_geul_no=-1&to_conf_no=&delete_yn=0&board_type=hm&C_PAGE=1&search_key=jemok&keyword="+ Estr +"&totalCnt=2559&paging=10");
            //검색할 URL
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
//        movielist = new LinkedList<>();
        //LinkedList name = new LinkedList();
        String readLine = null;
        //라인 읽어오기
        boolean cur=true;
        try {
            InputStreamReader isr = new InputStreamReader(url.openStream(), "UTF-8");
            BufferedReader br = new BufferedReader(isr);

            while ((readLine = br.readLine()) != null) {
                if(readLine.contains("first_mv_list_link")) {
                    //상영작 포함된 줄 찾기
//                    String []split = readLine.split("<strong class=\"blind\">");
//                    String []split2 = split[1].split("</strong>");
                    //스트링 구분
                    //name.add(split2[0]);
//                   movielist.add(new Movie_Data(split2[0], null, null));
                    cur=true;
                }
                if(readLine.contains("data-title=")) {
                    //글 제목 포함된 줄 찾기
                    String []split = readLine.split("\"");
                    String []split2 = readLine.split("<a href=\"");
                    String []split3 = split2[1].split("><img");
                    String []split4 = readLine.split("src=\"");
                    String []split5 = split4[1].split("\" width=");
                    //스트링 구분
                    //name.add(split[1]);
//                    movielist.add(new Movie_Data(split[1], split5[0], "http://movie.naver.com" + split3[0]));
                    if(cur)
                        mArray.add(new MovieInfo(split[1], split5[0], "http://movie.naver.com" + split3[0]));
                    else
                        mArray2.add(new MovieInfo(split[1], split5[0], "http://movie.naver.com" + split3[0]));
                }
                if(readLine.contains("second_mv_list_link")) {
                    //예정작 포함된 줄 찾기
//                    String []split = readLine.split("<strong class=\"blind\">");
//                    String []split2 = split[1].split("</strong>");
//                    //스트링 구분
//                    //name.add(split2[0]);
////                    movielist.add(new Movie_Data(split2[0], null, null));
//                    mArray.add(new MovieInfo(split2[0], "예정작", "www.daum.com" ,false ));
                    cur=false;
                }
                else
                    continue;
            }
//            for (int i=0; i<mArray.size(); i++) {
//                Toast.makeText(this, mArray.get(i).getImage(),Toast.LENGTH_SHORT).show();
//////                adapter.add(movielist.get(i).getName());
//////                //text.append(movielist.get(i).getName() + "\n" + movielist.get(i).getSrc() + "\n" + movielist.get(i).getImage() + "\n");
//////                //출력
//           }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
