package kr.ac.kumoh.ce.s20110547.movie2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by samsung on 2016-04-07.
 */
public class InfoDetail extends Activity {
    TextView title;
    Intent intent;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_info);
        intent = getIntent();
        title = (TextView)findViewById(R.id.title);
        title.setText(getIntent().getStringExtra("title"));
    }
}
