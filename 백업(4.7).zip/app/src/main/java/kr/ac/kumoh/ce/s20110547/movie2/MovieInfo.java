package kr.ac.kumoh.ce.s20110547.movie2;

/**
 * Created by samsung on 2016-04-07.
 */
public class MovieInfo {
    String name;
    String image;
    String src;

    public MovieInfo(String name_, String image_, String src_) {
        super();
        this.name = name_;
        this.image = image_;
        this.src = src_;
    }
    public String getName() {
        return name;
    }
    public String getImage() {
        return image;
    }
    public String getSrc() {
        return src;
    }
}
